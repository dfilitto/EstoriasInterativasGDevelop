gdjs.EstudarCode = {};
gdjs.EstudarCode.GDBackgroundObjects1= [];
gdjs.EstudarCode.GDBackgroundObjects2= [];
gdjs.EstudarCode.GDEstudarObjects1= [];
gdjs.EstudarCode.GDEstudarObjects2= [];
gdjs.EstudarCode.GDTextoEstudarObjects1= [];
gdjs.EstudarCode.GDTextoEstudarObjects2= [];
gdjs.EstudarCode.GDButtonIrObjects1= [];
gdjs.EstudarCode.GDButtonIrObjects2= [];

gdjs.EstudarCode.conditionTrue_0 = {val:false};
gdjs.EstudarCode.condition0IsTrue_0 = {val:false};
gdjs.EstudarCode.condition1IsTrue_0 = {val:false};
gdjs.EstudarCode.condition2IsTrue_0 = {val:false};
gdjs.EstudarCode.condition3IsTrue_0 = {val:false};
gdjs.EstudarCode.conditionTrue_1 = {val:false};
gdjs.EstudarCode.condition0IsTrue_1 = {val:false};
gdjs.EstudarCode.condition1IsTrue_1 = {val:false};
gdjs.EstudarCode.condition2IsTrue_1 = {val:false};
gdjs.EstudarCode.condition3IsTrue_1 = {val:false};


gdjs.EstudarCode.mapOfGDgdjs_46EstudarCode_46GDButtonIrObjects1Objects = Hashtable.newFrom({"ButtonIr": gdjs.EstudarCode.GDButtonIrObjects1});
gdjs.EstudarCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ButtonIr"), gdjs.EstudarCode.GDButtonIrObjects1);

gdjs.EstudarCode.condition0IsTrue_0.val = false;
gdjs.EstudarCode.condition1IsTrue_0.val = false;
gdjs.EstudarCode.condition2IsTrue_0.val = false;
{
gdjs.EstudarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.EstudarCode.mapOfGDgdjs_46EstudarCode_46GDButtonIrObjects1Objects, runtimeScene, true, false);
}if ( gdjs.EstudarCode.condition0IsTrue_0.val ) {
{
gdjs.EstudarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.EstudarCode.condition1IsTrue_0.val ) {
{
{gdjs.EstudarCode.conditionTrue_1 = gdjs.EstudarCode.condition2IsTrue_0;
gdjs.EstudarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8394532);
}
}}
}
if (gdjs.EstudarCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "EstudarFinal", false);
}}

}


};

gdjs.EstudarCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EstudarCode.GDBackgroundObjects1.length = 0;
gdjs.EstudarCode.GDBackgroundObjects2.length = 0;
gdjs.EstudarCode.GDEstudarObjects1.length = 0;
gdjs.EstudarCode.GDEstudarObjects2.length = 0;
gdjs.EstudarCode.GDTextoEstudarObjects1.length = 0;
gdjs.EstudarCode.GDTextoEstudarObjects2.length = 0;
gdjs.EstudarCode.GDButtonIrObjects1.length = 0;
gdjs.EstudarCode.GDButtonIrObjects2.length = 0;

gdjs.EstudarCode.eventsList0(runtimeScene);
return;

}

gdjs['EstudarCode'] = gdjs.EstudarCode;
