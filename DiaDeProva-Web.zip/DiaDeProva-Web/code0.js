gdjs.MenuCode = {};
gdjs.MenuCode.GDNomeJogoObjects1= [];
gdjs.MenuCode.GDNomeJogoObjects2= [];
gdjs.MenuCode.GDButtonPlayerObjects1= [];
gdjs.MenuCode.GDButtonPlayerObjects2= [];
gdjs.MenuCode.GDBlueBackgroundObjects1= [];
gdjs.MenuCode.GDBlueBackgroundObjects2= [];
gdjs.MenuCode.GDBookObjects1= [];
gdjs.MenuCode.GDBookObjects2= [];

gdjs.MenuCode.conditionTrue_0 = {val:false};
gdjs.MenuCode.condition0IsTrue_0 = {val:false};
gdjs.MenuCode.condition1IsTrue_0 = {val:false};
gdjs.MenuCode.condition2IsTrue_0 = {val:false};
gdjs.MenuCode.condition3IsTrue_0 = {val:false};
gdjs.MenuCode.conditionTrue_1 = {val:false};
gdjs.MenuCode.condition0IsTrue_1 = {val:false};
gdjs.MenuCode.condition1IsTrue_1 = {val:false};
gdjs.MenuCode.condition2IsTrue_1 = {val:false};
gdjs.MenuCode.condition3IsTrue_1 = {val:false};


gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDButtonPlayerObjects1Objects = Hashtable.newFrom({"ButtonPlayer": gdjs.MenuCode.GDButtonPlayerObjects1});
gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlayer"), gdjs.MenuCode.GDButtonPlayerObjects1);

gdjs.MenuCode.condition0IsTrue_0.val = false;
gdjs.MenuCode.condition1IsTrue_0.val = false;
gdjs.MenuCode.condition2IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDButtonPlayerObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MenuCode.condition0IsTrue_0.val ) {
{
gdjs.MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.MenuCode.condition1IsTrue_0.val ) {
{
{gdjs.MenuCode.conditionTrue_1 = gdjs.MenuCode.condition2IsTrue_0;
gdjs.MenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8362564);
}
}}
}
if (gdjs.MenuCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Inicio", false);
}}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDNomeJogoObjects1.length = 0;
gdjs.MenuCode.GDNomeJogoObjects2.length = 0;
gdjs.MenuCode.GDButtonPlayerObjects1.length = 0;
gdjs.MenuCode.GDButtonPlayerObjects2.length = 0;
gdjs.MenuCode.GDBlueBackgroundObjects1.length = 0;
gdjs.MenuCode.GDBlueBackgroundObjects2.length = 0;
gdjs.MenuCode.GDBookObjects1.length = 0;
gdjs.MenuCode.GDBookObjects2.length = 0;

gdjs.MenuCode.eventsList0(runtimeScene);
return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
