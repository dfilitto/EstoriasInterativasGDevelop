gdjs.BrincarFinalCode = {};
gdjs.BrincarFinalCode.GDBackgroundObjects1= [];
gdjs.BrincarFinalCode.GDBackgroundObjects2= [];
gdjs.BrincarFinalCode.GDEstudarObjects1= [];
gdjs.BrincarFinalCode.GDEstudarObjects2= [];
gdjs.BrincarFinalCode.GDTextoEstudarObjects1= [];
gdjs.BrincarFinalCode.GDTextoEstudarObjects2= [];
gdjs.BrincarFinalCode.GDButtonIrObjects1= [];
gdjs.BrincarFinalCode.GDButtonIrObjects2= [];

gdjs.BrincarFinalCode.conditionTrue_0 = {val:false};
gdjs.BrincarFinalCode.condition0IsTrue_0 = {val:false};


gdjs.BrincarFinalCode.asyncCallback8382500 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}
gdjs.BrincarFinalCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.BrincarFinalCode.asyncCallback8382500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BrincarFinalCode.eventsList1 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.BrincarFinalCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.BrincarFinalCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BrincarFinalCode.GDBackgroundObjects1.length = 0;
gdjs.BrincarFinalCode.GDBackgroundObjects2.length = 0;
gdjs.BrincarFinalCode.GDEstudarObjects1.length = 0;
gdjs.BrincarFinalCode.GDEstudarObjects2.length = 0;
gdjs.BrincarFinalCode.GDTextoEstudarObjects1.length = 0;
gdjs.BrincarFinalCode.GDTextoEstudarObjects2.length = 0;
gdjs.BrincarFinalCode.GDButtonIrObjects1.length = 0;
gdjs.BrincarFinalCode.GDButtonIrObjects2.length = 0;

gdjs.BrincarFinalCode.eventsList1(runtimeScene);
return;

}

gdjs['BrincarFinalCode'] = gdjs.BrincarFinalCode;
