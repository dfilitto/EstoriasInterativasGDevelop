gdjs.EstudarFinalCode = {};
gdjs.EstudarFinalCode.GDBackgroundObjects1= [];
gdjs.EstudarFinalCode.GDBackgroundObjects2= [];
gdjs.EstudarFinalCode.GDEstudarObjects1= [];
gdjs.EstudarFinalCode.GDEstudarObjects2= [];
gdjs.EstudarFinalCode.GDTextoEstudarObjects1= [];
gdjs.EstudarFinalCode.GDTextoEstudarObjects2= [];
gdjs.EstudarFinalCode.GDButtonIrObjects1= [];
gdjs.EstudarFinalCode.GDButtonIrObjects2= [];

gdjs.EstudarFinalCode.conditionTrue_0 = {val:false};
gdjs.EstudarFinalCode.condition0IsTrue_0 = {val:false};


gdjs.EstudarFinalCode.asyncCallback8388380 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}
gdjs.EstudarFinalCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.EstudarFinalCode.asyncCallback8388380(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EstudarFinalCode.eventsList1 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.EstudarFinalCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.EstudarFinalCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EstudarFinalCode.GDBackgroundObjects1.length = 0;
gdjs.EstudarFinalCode.GDBackgroundObjects2.length = 0;
gdjs.EstudarFinalCode.GDEstudarObjects1.length = 0;
gdjs.EstudarFinalCode.GDEstudarObjects2.length = 0;
gdjs.EstudarFinalCode.GDTextoEstudarObjects1.length = 0;
gdjs.EstudarFinalCode.GDTextoEstudarObjects2.length = 0;
gdjs.EstudarFinalCode.GDButtonIrObjects1.length = 0;
gdjs.EstudarFinalCode.GDButtonIrObjects2.length = 0;

gdjs.EstudarFinalCode.eventsList1(runtimeScene);
return;

}

gdjs['EstudarFinalCode'] = gdjs.EstudarFinalCode;
