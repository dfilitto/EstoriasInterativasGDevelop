gdjs.BrincarCode = {};
gdjs.BrincarCode.GDBackgroundObjects1= [];
gdjs.BrincarCode.GDBackgroundObjects2= [];
gdjs.BrincarCode.GDBrincarObjects1= [];
gdjs.BrincarCode.GDBrincarObjects2= [];
gdjs.BrincarCode.GDTextoBrincarObjects1= [];
gdjs.BrincarCode.GDTextoBrincarObjects2= [];
gdjs.BrincarCode.GDButtonIrObjects1= [];
gdjs.BrincarCode.GDButtonIrObjects2= [];

gdjs.BrincarCode.conditionTrue_0 = {val:false};
gdjs.BrincarCode.condition0IsTrue_0 = {val:false};
gdjs.BrincarCode.condition1IsTrue_0 = {val:false};
gdjs.BrincarCode.condition2IsTrue_0 = {val:false};
gdjs.BrincarCode.condition3IsTrue_0 = {val:false};
gdjs.BrincarCode.conditionTrue_1 = {val:false};
gdjs.BrincarCode.condition0IsTrue_1 = {val:false};
gdjs.BrincarCode.condition1IsTrue_1 = {val:false};
gdjs.BrincarCode.condition2IsTrue_1 = {val:false};
gdjs.BrincarCode.condition3IsTrue_1 = {val:false};


gdjs.BrincarCode.mapOfGDgdjs_46BrincarCode_46GDButtonIrObjects1Objects = Hashtable.newFrom({"ButtonIr": gdjs.BrincarCode.GDButtonIrObjects1});
gdjs.BrincarCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ButtonIr"), gdjs.BrincarCode.GDButtonIrObjects1);

gdjs.BrincarCode.condition0IsTrue_0.val = false;
gdjs.BrincarCode.condition1IsTrue_0.val = false;
gdjs.BrincarCode.condition2IsTrue_0.val = false;
{
gdjs.BrincarCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.BrincarCode.mapOfGDgdjs_46BrincarCode_46GDButtonIrObjects1Objects, runtimeScene, true, false);
}if ( gdjs.BrincarCode.condition0IsTrue_0.val ) {
{
gdjs.BrincarCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.BrincarCode.condition1IsTrue_0.val ) {
{
{gdjs.BrincarCode.conditionTrue_1 = gdjs.BrincarCode.condition2IsTrue_0;
gdjs.BrincarCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8376260);
}
}}
}
if (gdjs.BrincarCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "BrincarFinal", false);
}}

}


{


{
}

}


};

gdjs.BrincarCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BrincarCode.GDBackgroundObjects1.length = 0;
gdjs.BrincarCode.GDBackgroundObjects2.length = 0;
gdjs.BrincarCode.GDBrincarObjects1.length = 0;
gdjs.BrincarCode.GDBrincarObjects2.length = 0;
gdjs.BrincarCode.GDTextoBrincarObjects1.length = 0;
gdjs.BrincarCode.GDTextoBrincarObjects2.length = 0;
gdjs.BrincarCode.GDButtonIrObjects1.length = 0;
gdjs.BrincarCode.GDButtonIrObjects2.length = 0;

gdjs.BrincarCode.eventsList0(runtimeScene);
return;

}

gdjs['BrincarCode'] = gdjs.BrincarCode;
