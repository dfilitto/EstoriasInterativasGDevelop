gdjs.InicioCode = {};
gdjs.InicioCode.GDTextoInicialObjects1= [];
gdjs.InicioCode.GDTextoInicialObjects2= [];
gdjs.InicioCode.GDBackgroundObjects1= [];
gdjs.InicioCode.GDBackgroundObjects2= [];
gdjs.InicioCode.GDBook2Objects1= [];
gdjs.InicioCode.GDBook2Objects2= [];
gdjs.InicioCode.GDGirlObjects1= [];
gdjs.InicioCode.GDGirlObjects2= [];

gdjs.InicioCode.conditionTrue_0 = {val:false};
gdjs.InicioCode.condition0IsTrue_0 = {val:false};
gdjs.InicioCode.condition1IsTrue_0 = {val:false};
gdjs.InicioCode.condition2IsTrue_0 = {val:false};
gdjs.InicioCode.condition3IsTrue_0 = {val:false};
gdjs.InicioCode.conditionTrue_1 = {val:false};
gdjs.InicioCode.condition0IsTrue_1 = {val:false};
gdjs.InicioCode.condition1IsTrue_1 = {val:false};
gdjs.InicioCode.condition2IsTrue_1 = {val:false};
gdjs.InicioCode.condition3IsTrue_1 = {val:false};


gdjs.InicioCode.mapOfGDgdjs_46InicioCode_46GDBook2Objects1Objects = Hashtable.newFrom({"Book2": gdjs.InicioCode.GDBook2Objects1});
gdjs.InicioCode.mapOfGDgdjs_46InicioCode_46GDGirlObjects1Objects = Hashtable.newFrom({"Girl": gdjs.InicioCode.GDGirlObjects1});
gdjs.InicioCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Book2"), gdjs.InicioCode.GDBook2Objects1);

gdjs.InicioCode.condition0IsTrue_0.val = false;
gdjs.InicioCode.condition1IsTrue_0.val = false;
gdjs.InicioCode.condition2IsTrue_0.val = false;
{
gdjs.InicioCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.InicioCode.mapOfGDgdjs_46InicioCode_46GDBook2Objects1Objects, runtimeScene, true, false);
}if ( gdjs.InicioCode.condition0IsTrue_0.val ) {
{
gdjs.InicioCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.InicioCode.condition1IsTrue_0.val ) {
{
{gdjs.InicioCode.conditionTrue_1 = gdjs.InicioCode.condition2IsTrue_0;
gdjs.InicioCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8369084);
}
}}
}
if (gdjs.InicioCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Estudar", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Girl"), gdjs.InicioCode.GDGirlObjects1);

gdjs.InicioCode.condition0IsTrue_0.val = false;
gdjs.InicioCode.condition1IsTrue_0.val = false;
gdjs.InicioCode.condition2IsTrue_0.val = false;
{
gdjs.InicioCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.InicioCode.mapOfGDgdjs_46InicioCode_46GDGirlObjects1Objects, runtimeScene, true, false);
}if ( gdjs.InicioCode.condition0IsTrue_0.val ) {
{
gdjs.InicioCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.InicioCode.condition1IsTrue_0.val ) {
{
{gdjs.InicioCode.conditionTrue_1 = gdjs.InicioCode.condition2IsTrue_0;
gdjs.InicioCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8370068);
}
}}
}
if (gdjs.InicioCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Brincar", false);
}}

}


};

gdjs.InicioCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.InicioCode.GDTextoInicialObjects1.length = 0;
gdjs.InicioCode.GDTextoInicialObjects2.length = 0;
gdjs.InicioCode.GDBackgroundObjects1.length = 0;
gdjs.InicioCode.GDBackgroundObjects2.length = 0;
gdjs.InicioCode.GDBook2Objects1.length = 0;
gdjs.InicioCode.GDBook2Objects2.length = 0;
gdjs.InicioCode.GDGirlObjects1.length = 0;
gdjs.InicioCode.GDGirlObjects2.length = 0;

gdjs.InicioCode.eventsList0(runtimeScene);
return;

}

gdjs['InicioCode'] = gdjs.InicioCode;
